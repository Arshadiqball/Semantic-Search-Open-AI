/**
 * Admin JavaScript for ATW Semantic Search Resume Plugin
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Add any admin-specific JavaScript here if needed
        console.log('ATW Semantic Search Admin loaded');
    });
    
})(jQuery);

